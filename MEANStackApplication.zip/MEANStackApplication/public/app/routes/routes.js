firstApp.config(function($stateProvider) {
    $stateProvider
        .state('home', {
            url: '/',
            abstract: true,
            templateUrl: '/partials/home.html'
        })
        .state('home.main', {
            url: '',
            templateUrl: '/partials/home_main.html'
        })
        .state('home.login', {
            url: '/login',
            templateUrl: '/partials/login.html',
            // controller: 'loginController'
        })
        .state('home.registration', {
            url: '/registration',
            templateUrl: '/partials/registartion.html',
            controller: 'registrationController'
        });
});