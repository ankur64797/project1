firstApp.controller('registrationController', ['$scope', 'mainService', '$http', function($scope, mainService, $http) {

    $scope.saveRegistration = function(registrationData) {
        console.log(registrationData);
        mainService.saveRegistration(registrationData)
            .then(function(response) {

            })
            .catch(function(error) {

            })
    }
}])