// require('../model/registration.js');
// var registrationModel = mongoose.model('registrationModel');

exports.mainFn = function(req, res) {
    // res.render('layout', { title: "Registration Form" });
    registrationModel.find({}, function(err, result) {
        res.render('layout', {
            title: "Registration Form",
            result: result
        });
    });
};

exports.saveRegistration = function(req, res) {
    console.log(req.body);
    // var registrationData = new registrationModel(req.body);
    // registrationData.save(function(err, result) {
    //     if (result) {
    //         console.log("Saved Successfully");
    //         res.redirect('/');
    //     }
    // });
};